!prefix=one_test

# seq check
Checks whether sequence program executes

!program=seq 10

```output
1
2
3
4
5
6
7
8
9
10
```
